const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const port = 3000;

app.use(express.static("."));
app.use(express.urlencoded({extended:false}));
app.use(express.json());


app.get('/',(req,res)=>{
    fs.readFile(path.join(__dirname,'index.html'),'utf-8',(err,data)=>{
        if(err){
            return res.status(500).send('Error to read file');
        }
        res.send(data);
    })
})

app.get('/getdata',(req,res)=>{
    fs.readFile(path.join(__dirname,'data.json'),'utf-8',(err,data)=>{
        if(err){
            return res.status(500).send('Error to fetch data');
        }
        res.json(JSON.parse(data));
    })
})

app.post('/create',(req,res)=>{
    const newData = {
        uid : req.body.uid,
        name : req.body.name,
        price : req.body.price
    }

    fs.readFile(path.join(__dirname,'data.json'),'utf-8',(err,data)=>{
        if(err){
            res.status(500).send('Unable to create');
        }

        const item = JSON.parse(data);
        item.push(newData);
        fs.writeFile(path.join(__dirname,('data.json')),JSON.stringify(item,null,2),(err,data)=>{
            if(err){
                return res.status(500).send('Unable to create');
            }
            res.redirect('/');
        })
    })
})

app.delete('/delete/:uid',(req,res)=>{
    const uidToDelete = req.params.uid;

    fs.readFile(path.join(__dirname,'data.json'),'utf-8',(err,data)=>{
        if(err){
            return res.status(500).send('Unable to readfile');
        }
        let items = JSON.parse(data);
        items = items.filter(item => String(item.uid) !== uidToDelete);

        fs.writeFile(path.join(__dirname,'data.json'),JSON.stringify(items,null,2),(err,data)=>{
            if(err){
                return res.status(500).send('Unable to write file');
            }
            res.status(200).send("item deleted successfully");
        })
    })
})

app.listen(port,(err)=>{
    if(err){
        res.status(500).send("Error");
    }
    else{
        console.log(`server started at https://localhost:3000`);
    }
})