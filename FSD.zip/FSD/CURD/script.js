

const fetchData = document.getElementById("fetch-data");

fetchData.addEventListener("click", () => {
  fetch("/getdata")
    .then((response) => {
      if (!response.ok) {
        throw new Error("error");
      }

      return response.json();
    })
    .then((data) => {
      console.log(data);  // Check the structure of the data here
      const tbody = document.querySelector("tbody");
      tbody.innerHTML = "";

      data.forEach((item) => {
        console.log(item);  // Check each item object for uid
        
        const tr = document.createElement("tr");

        const td1 = document.createElement("td");
        td1.innerText = item.uid;

        const td2 = document.createElement("td");
        td2.innerText = item.name;

        const td3 = document.createElement("td");
        td3.innerText = item.price;

        const td4 = document.createElement("td");
        const btn1 = document.createElement("button");
        btn1.innerText = "Update";
        td4.appendChild(btn1);

        btn1.addEventListener('click',()=>{
          // const newid = prompt("Enter new id:",item.uid);
          const newName = prompt("Enter new name:", item.name);
          const newprice = prompt("Enter new price:", item.price);

          if(newName && newprice){
            fetch(`/update/${item.uid}`,{
              method:"PUT",
              headers:{
                "Content-Type":"application/json",
              },
              body:JSON.stringify({
                name: newName,
                price: newprice,
              }),
            })
            .then((response)=>{
              if(!response.ok){
                throw new Error("Error updating this item");
              }
              fetchData.click();
            })
            .catch((error)=>{
              console.log("There was a problem to deletiong the item",error);
            })
            
          }


        })

        const td5 = document.createElement("td");
        const btn2 = document.createElement("button");
        btn2.innerText = "Delete";
        
        btn2.addEventListener("click", () => {
          console.log(item.uid);  // Debugging: Check if uid is printed here
          fetch(`/delete/${item.uid}`, {
            method: "DELETE"
          })
            .then((response) => {
              if (!response.ok) {
                throw new Error("Error deleting item");
              }
              fetchData.click();
            })
            .catch((error) => {
              console.error("There was a problem deleting the item:", error);
            });
        });

        td5.appendChild(btn2);
        tr.appendChild(td1);
        tr.appendChild(td2);
        tr.appendChild(td3);
        tr.appendChild(td4);
        tr.appendChild(td5);

        tbody.appendChild(tr);
      });
    })
    .catch((error) => {
      console.error("There was a problem with the fetch operation:", error);
    });
});
