const express = require("express");
const path = require("path");
const fs = require("fs");

const app = express();
const port = 3000;

// Use body parser middleware to handle form submissions
app.use(express.static("."));
app.use(express.urlencoded({ extended: true })); // Parse URL-encoded bodies
app.use(express.json()); // Parse JSON bodies (for API requests, if needed)

app.get("/", (req, res) => {
  fs.readFile(path.join(__dirname, "index.html"), "utf-8", (err, data) => {
    if (err) {
      return res.status(500).send("Error to reading this file");
    }
    res.send(data);
  });
});

//Shivanshugarg@123
// mongodb+srv://<gargshivanshu2>:<nJw37hbMYmWMZSS7>@cluster0.brg1zew.mongodb.net/



app.get("/getdata", (req, res) => {
  fs.readFile(path.join(__dirname, "data.json"), "utf-8", (err, data) => {
    if (err) {
      return res.status(500).send("Error to reading this file");
    }
    res.json(JSON.parse(data));
  });
});


// ! create Starts
app.post("/create", (req, res) => {
  const newData = {
    uid: req.body.uid,
    name: req.body.name,
    price: req.body.price,
  };

  fs.readFile(path.join(__dirname, "data.json"), "utf-8", (err, data) => {
    if (err) {
      return res.status(500).send("Error saving data");
    }

    const item = JSON.parse(data);
    item.push(newData);

    fs.writeFile(
      path.join(__dirname, "data.json"),
      JSON.stringify(item, null, 2),
      (err, data) => {
        if (err) {
          res.status(500).send("Error saving data");
        }
        res.redirect("/");
      }
    );
  });
});

// ! create End

// ! update start

app.put("/update/:uid", (req, res) => {
  const uidToUpdate = req.params.uid;
  const updatedData = {
    name: req.body.name,
    price: req.body.price,
  };
  fs.readFile(path.join(__dirname, "data.json"), "utf-8", (err, data) => {
    if (err) {
      return res.status(500).send("Unable to read file");
    }

    let items = JSON.parse(data);

    const itemIndex = items.findIndex(
      (item) => String(item.uid) === uidToUpdate
    );

    if (itemIndex === -1) {
      return res.status(404).send("Item not found");
    }

    items[itemIndex].name = updatedData.name;
    items[itemIndex].price = updatedData.price;

    fs.writeFile(
      path.join(__dirname, "data.json"),
      JSON.stringify(items, null, 2),
      (err) => {
        if (err) {
          return res.status(500).send("Unable to write file");
        }
        res.status(200).send("Uid Updated successfully");
      }
    );
  });
});
// ! update end

// ! delete start

app.delete("/delete/:uid", (req, res) => {
  const uidToDelete = req.params.uid;
  fs.readFile(path.join(__dirname, "data.json"), "utf-8", (err, data) => {
    if (err) {
      res.status(500).send("Unable to delete");
    }
    let items = JSON.parse(data);

    items = items.filter((item) => String(item.uid) !== uidToDelete);
    console.log(`Deleting item with UID: ${uidToDelete}`);

    fs.writeFile(
      path.join(__dirname, "data.json"),
      JSON.stringify(items, null, 2),
      (err) => {
        if (err) {
          return res.status(500).send("unable to delete uid");
        }
        res.status(200).send("item deleted successfully");
      }
    );
  });
});

// ! delete end
app.listen(port, () => {
  console.log(`server started at localhost:${3000}`);
});
