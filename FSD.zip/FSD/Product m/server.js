const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static('.'));

const mongodbURI = "mongodb+srv://gargshivanshu22:Shivanshu123@cluster0.brg1zew.mongodb.net/products_db?retryWrites=true&w=majority";

mongoose.connect(mongodbURI)
    .then(() => console.log("Mongodb connected Successfully"))
    .catch((err) => console.error("Mongodb connection error:", err));

// Product Schema
const ProductSchema = new mongoose.Schema({
    product_id: Number,
    product_name: String,
    product_category: String
});

const Product = mongoose.model('Product', ProductSchema);

// Serve HTML file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Fetch products by category
app.get('/GetProducts', (req, res) => {
    const category = req.query.category;

    Product.find({ product_category: category })
        .then((products) => res.json(products))
        .catch((err) => res.status(500).send("Error fetching products: " + err));
});

// Start the server
app.listen(port, () => {
    console.log(`Server started at http://localhost:${port}`);
});
