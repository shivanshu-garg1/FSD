const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));  // Parse URL-encoded bodies
app.use(express.static("."));  // Serve static files

const mongoURI = "mongodb+srv://gargshivanshu22:Shivanshu123@cluster0.brg1zew.mongodb.net/products_db?retryWrites=true&w=majority";

mongoose.connect(mongoURI)
  .then(() => console.log("MongoDB connected successfully"))
  .catch(err => console.error("MongoDB connection error:", err));


const itemSchema = new mongoose.Schema({
    uid: Number,
    name: String,
    price: Number,
});

const Item = mongoose.model('Item', itemSchema);

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/getdata', (req, res) => {
    Item.find({})
        .then(items => res.json(items))
        .catch(err => res.status(500).send('Error fetching items: ' + err));
});

app.post('/create', (req, res) => {
    const newItem = new Item({
        uid: req.body.uid,
        name: req.body.name,
        price: req.body.price
    });

    newItem.save()
        .then(() => res.redirect('/'))
        .catch(err => res.status(500).send("Error saving data: " + err));
});

app.patch('/update/:uid', (req, res) => {
    const uidToUpdate = req.params.uid;

    Item.findOneAndUpdate({ uid: uidToUpdate }, req.body, { new: true })
        .then(updatedItem => {
            if (!updatedItem) {
                return res.status(404).send("Item not found");
            }
            res.status(200).send('Item updated successfully');
        })
        .catch(err => res.status(500).send("Error updating item: " + err));
});

app.delete('/delete/:uid', (req, res) => {
    const uidToDelete = req.params.uid;

    Item.findOneAndDelete({ uid: uidToDelete })
        .then(deletedItem => {
            if (!deletedItem) {
                return res.status(404).send("Item not found");
            }
            res.status(200).send("Item deleted successfully");
        })
        .catch(err => res.status(500).send("Error deleting item: " + err));
});

// Start the server
app.listen(port, () => {
    console.log(`Server started at http://localhost:${port}`);
});
