const fetchData = document.getElementById("fetch-data");

fetchData.addEventListener('click',()=>{
    fetch('/getdata')
    .then((response) =>{
        if(!response.ok){
            throw new Error('Error');
        }
        return response.json();
    })
    .then((data)=>{
        console.log(data);
        const tbody = document.querySelector("tbody");
        tbody.innerHTML ="";

        data.forEach((item)=>{
            console.log(item);
            const tr = document.createElement("tr");

        const td1 = document.createElement("td");
        td1.innerText = item.uid;

        const td2 = document.createElement("td");
        td2.innerText = item.name;

        const td3 = document.createElement("td");
        td3.innerText = item.price;


        const td4 = document.createElement("td");
        const btn1 = document.createElement("button");
        btn1.innerText = "Update";
        td4.appendChild(btn1);
        btn1.addEventListener('click',()=>{
            const newName = prompt("Enter new name:",item.name)
            const newPrice = prompt("Enter new name:",item.price)

            if(newName && newPrice){
                fetch(`/update/${item.uid}`,{
                    method:"PATCH",
                    headers:{
                        "Content-Type":"application/json",
                    },
                    body:JSON.stringify({
                        name:newName,
                        price: newPrice,
                    })
                })
                .then((response)=>{
                    if(!response.ok){
                      throw new Error("Error updating this item");
                    }
                    fetchData.click();
                  })
                  .catch((error)=>{
                    console.log("There was a problem to deletiong the item",error);
                  })
            }
        })

        const td5 = document.createElement("td");
        const btn2 = document.createElement("button");
        btn2.innerText = "Delete";

        btn2.addEventListener('click',()=>{
            fetch(`/delete/${item.uid}`,{
                method:"DELETE"
            })
            .then((response) => {
                if (!response.ok) {
                  throw new Error("Error deleting item");
                }
                fetchData.click();
        })
        .catch((error) => {
            console.error("There was a problem deleting the item:", error);
          });
    })

        td5.appendChild(btn2);
        tr.appendChild(td1);
        tr.appendChild(td2);
        tr.appendChild(td3);
        tr.appendChild(td4);
        tr.appendChild(td5);

        tbody.appendChild(tr);
        
        })
    .catch((error) => {
        console.error("There was a problem with the fetch operation:", error);
      });
})
})