const express = require('express');
const fs = require('fs');
const path = require('path');
const session = require('express-session');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Middleware for parsing request bodies
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Set up session management
app.use(session({
    secret: 'your_secret_key', // Replace with a strong secret
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set to true if using HTTPS
}));

// Serve the login HTML page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

// Serve the signup HTML page
app.get('/signup', (req, res) => {
    res.sendFile(path.join(__dirname, 'signup.html'));
});

// Login endpoint
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    fs.readFile(path.join(__dirname, 'users.json'), 'utf-8', (err, data) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Error reading user data.' });
        }

        const users = JSON.parse(data);
        const user = users.find(user => user.username === username && user.password === password);

        if (user) {
            // Store user info in session
            req.session.user = { username: user.username };
            return res.json({ success: true });
        } else {
            return res.json({ success: false });
        }
    });
});

// Signup endpoint
app.post('/signup', (req, res) => {
    const { username, password } = req.body;

    fs.readFile(path.join(__dirname, 'users.json'), 'utf-8', (err, data) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Error reading user data.' });
        }

        const users = JSON.parse(data);
        const existingUser = users.find(user => user.username === username);

        if (existingUser) {
            return res.json({ success: false, message: 'Username already exists.' });
        }

        // Add new user to the users array
        const newUser = { username, password };
        users.push(newUser);

        // Write updated users array back to the JSON file
        fs.writeFile(path.join(__dirname, 'users.json'), JSON.stringify(users, null, 2), err => {
            if (err) {
                return res.status(500).json({ success: false, message: 'Error saving user data.' });
            }
            return res.json({ success: true });
        });
    });
});

// Endpoint to check session
app.get('/session', (req, res) => {
    if (req.session.user) {
        res.json({ loggedIn: true, user: req.session.user });
    } else {
        res.json({ loggedIn: false });
    }
});

// Logout endpoint
app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Error logging out.' });
        }
        res.json({ success: true });
    });
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
