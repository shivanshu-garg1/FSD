const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const app = express();

// Connect to MongoDB Atlas
mongoose.connect('mongodb+srv://gargshivanshu2:<password>@cluster0.mongodb.net/mydatabase', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("Connected to MongoDB Atlas");
}).catch(err => {
    console.error("Error connecting to MongoDB Atlas", err);
});

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');

// Schema and Model for Users
const userSchema = new mongoose.Schema({
    name: String,
    age: Number
});

const User = mongoose.model('User', userSchema);

// Schema and Model for Cart
const cartSchema = new mongoose.Schema({
    productName: String,
    quantity: Number,
    netPrice: Number
});

const Cart = mongoose.model('Cart', cartSchema);

// Routes
// Home route
app.get('/', (req, res) => {
    res.render('index');
});

// READ operation - Display all users in tabular format
app.get('/users', (req, res) => {
    User.find({}, (err, users) => {
        if (err) {
            console.error(err);
            res.status(500).send("Error retrieving users");
        } else {
            res.render('users', { users });
        }
    });
});

// CREATE user form
app.get('/users/new', (req, res) => {
    res.render('addUser');
});

// CREATE user operation
app.post('/users', (req, res) => {
    const newUser = new User({
        name: req.body.name,
        age: req.body.age
    });

    newUser.save((err) => {
        if (err) {
            console.error(err);
            res.status(500).send("Error saving user");
        } else {
            res.redirect('/users');
        }
    });
});

// Display cart page
app.get('/cart', (req, res) => {
    Cart.find({}, (err, cartItems) => {
        if (err) {
            console.error(err);
            res.status(500).send("Error retrieving cart");
        } else {
            res.render('myCart', { cartItems });
        }
    });
});

// Add to cart operation (with quantity and net price update)
app.post('/cart', (req, res) => {
    const { productName, quantity, netPrice } = req.body;

    // Check if the product is already in the cart
    Cart.findOne({ productName }, (err, item) => {
        if (err) {
            console.error(err);
            res.status(500).send("Error finding cart item");
        } else if (item) {
            // Update quantity and netPrice if product already in cart
            item.quantity += parseInt(quantity);
            item.netPrice += parseFloat(netPrice);
            item.save((err) => {
                if (err) {
                    console.error(err);
                    res.status(500).send("Error updating cart");
                } else {
                    res.redirect('/cart');
                }
            });
        } else {
            // Add new item to cart
            const newCartItem = new Cart({
                productName,
                quantity: parseInt(quantity),
                netPrice: parseFloat(netPrice)
            });

            newCartItem.save((err) => {
                if (err) {
                    console.error(err);
                    res.status(500).send("Error adding to cart");
                } else {
                    res.redirect('/cart');
                }
            });
        }
    });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
