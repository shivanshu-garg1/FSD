
const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const port = 3000;

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/getPeople', (req, res) => {
    const region = req.query.region;

    // Read the users.json file
    fs.readFile(path.join(__dirname, 'users.json'), 'utf-8', (err, data) => {
        if (err) {
            return res.status(500).send("Error reading user data");
        }

        const users = JSON.parse(data);
        const filteredUsers = users.filter(user => user.region === region);

        // Send filtered users as response
        res.json(filteredUsers);
    });
});

app.listen(port,()=>{
    console.log("Server Started");
})
